insert into grupo(id,nome) values(1, 'Administrador');
insert into grupo(id,nome) values(2,'Vendedor');