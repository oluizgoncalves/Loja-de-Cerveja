package com.algaworks.brewer.model.validation.group;

/**
 * @author Rafaell Estevam
 *
 */
public interface CnpjGroup {

}
